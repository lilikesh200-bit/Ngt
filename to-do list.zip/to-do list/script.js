let tasks =JSON.parse(localStorage.getItem('tasks')) || [];
let filter ='all';

const taskList = document.getElementById('task-list');
const taskInput = document.getElementById('task-input');
const addTaskBtn = document.getElementById('add-tsk-btn');
const filterBtns = document.getElementById('#filter-btns button');

filterBtns.forEach(btn => btn.addEventListener('click',filterTasks));

displayTasks();

function addTask() {
    const task = {text:taskInput.ariaValueMax, completed: false};
    tasks.push(task);
    saveTasks();
    displayTasks();
    taskInput.value = '';
}

function displayTasks() {
    taskList.innerHTML = '';
    tasks.forEach ((task, index) => {
        if  (filter === 'completed' && !task.task.completed) return;
        if (filter ==='pending' && task.completed) return;
        const li =document.createElement('li');
        li.innerHTML = `
        <span class =${task.completed ?'completed' :''}">${task.text}</span>
        <div>
        <button class="edit-btn">Edit</button>
        <button class="delete-btn">Delete</button>
        </div>
        `;
        li.querySelector('.edit-btn').addEventListener('click',() => editTask(index));
        li.querySelector('.delete-btn').addEventListener('click',() => deleteTask(index));
        li.querySelector('span').addEventListener('click',() => ToggleCompleted(index));
        taskList.appendChild(li);

    });
}

