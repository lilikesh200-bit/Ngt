const questions =[
    {
    question: "What is the capital of France?",
    answers:[
        {text: "Paris", correct: true},
        {text: "London", correct: false},
        {text: "Berline", correct: false},
        {text: "Madrid", correct:false},

    ]
},
{
question: "Which planet is known as the Red Planet?",
answers: [
{text: "Earth", correct: false},
{text: "Mars", correct: true},
{text: "Jupiter", correct: false},
{text: "Saturn", correct: false}

]
},
{
    question: "What is the largest mammal in the world?",
    answers:[
        {text: "Elephant", correct:false},
        {text: "Blue Whale", correct: true},
        {text: "Giraffe", correct: false},
        {text: "Great White Shark", correct: false}
    ]

},
{
    question: "What is the chemical symbol of water?",
    answers:[
        {text: "H2O", correct: true},
        {text: "O2", correct: false},
        {text: "CO2", correct: false},
        {text: "H2", correct: false}
    ]
},
{
    question: "Which gas do plants absorb from the atmosphere?",
    answer: [
        {text: "Oxygen", correct: false},
        {text: "Carbon dioxide", correct: true},
        {text: "Nitrogen", correct: false},
        {text: "Hydrogen", correct: false}
    ]

}
];
let currentQuestionIndex =0;
let score = 0;

//DOM Elements
const questionContainer =
document.getElementById('question-container');
const questionElement =
document.getElementById('question');
const answerButtons=
document.getElementById('answer-buttons');
const scoreContainer =
document.getElementById('score-container');
const scoreElement =
document.getElementById('score');
const restartButton =
document.getElementById('restart-button');

//Start the Quiz
startGame();

function startGame() {
    currentQuestionIndex = 0;
    score = 0;
    scoreContainer.classList.add('hidden');

    questionContainer.classList.remove(hidden);
    nextQuestion();
}

function nextQuestion() {
    resetState();
    const currentQuestion =
    questions[currentQuestionIndex];
    questionElement.innerText =
    currentQuestion.question;
    currentQuestion.question.answers.forEach(answer => {
        const button =
        document.createElement('button');
        button.innerText = answer.text;
        button.classList.add('btn');
        button.addEventListener('click ', () => selectAnswer(answer));
        answerButtons.appendChild(button);
    });
}
function resetState() {
    while (answerButtons.firstChild) {
        answerButtons.removeChild(answerButtons.firstChild);
    }
}

function selectAnswer(answer) {
    const correct = answer.correct;
    if(correct) {
        score++;
        alert("correct!");
    } else {
        alert("Wrong answer!")
    }
    

    currentQuestionIndex++;
    if(currentQuestionIndex < questions.length)
    {
        nextQuestion();
    } else {
        showScore();
    }
    }

function showScore() {
    questionContainer.classList.add('hidden');
    scoreContainer.classList.remove('hidden');
    scoreElement.innerText = score;
}
//Restart Button
restartButton.addEventListener('click', startGame);

